package com.booking.dto;

import lombok.Data;

@Data
public class SightseeingDTO {

	private String location;
	private String description;
}
