package com.booking.dto;

import lombok.Data;

@Data
public class ItineraryDTO {
	private int dayNumber;
	private String activityTitle;
	private String activityDescription;

}
