package com.booking.dto;

import lombok.Data;

@Data
public class PaymentResponseDTO {
    private Long paymentId;
    private Long userId;
    private Long bookingId;
    private double amount;
    private String status;
    private String paymentMethod;
    private String currency;

}