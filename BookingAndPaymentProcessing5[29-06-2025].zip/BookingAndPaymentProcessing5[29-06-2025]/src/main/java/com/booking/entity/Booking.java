package com.booking.entity;

import java.time.LocalDate;
import lombok.Data;
import jakarta.persistence.*;
 
@Data
@Entity
public class Booking {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long bookingId;
    private Long userId;
    private Long packageId;

    @Column(name= "trip_start_date")
    private LocalDate tripStartDate;
    
    @Column(name= "trip_end_date")
    private LocalDate tripEndDate;
    
    private String status;
    private Long paymentId;
    private Integer insuranceId;

}