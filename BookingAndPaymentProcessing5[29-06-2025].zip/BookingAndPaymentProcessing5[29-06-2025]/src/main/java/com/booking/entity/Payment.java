package com.booking.entity;

import lombok.Data;
import jakarta.persistence.*;

@Data
@Entity
public class Payment {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long paymentId;
	private Long userId;
    private Long bookingId;
    private double amount;
    private String status;
    
    @Column(nullable = false)
    private String paymentMethod; // Should be "Credit Card" or "Debit Card"
 
    private String currency;
 
    @Transient
    private String cardNumber;  // Not stored in DB
 
    @Transient
    private String cvv;			// Not stored in DB
 
    @Transient
    private String atmPin;		// Not stored in DB
    
    @Transient
    private String expiryDate;	// Not stored in DB
    
}