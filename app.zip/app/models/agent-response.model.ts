export interface AgentResponse {
    responseId: number;
    agentId: number;
    responseMessage: string;
    responseTime: string;
    reviewId: number;
    packageId: number;
  }